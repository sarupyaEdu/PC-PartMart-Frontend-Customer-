import { useState } from "react";
import { useCart } from "../context/CartContext";
import { createOrder } from "../api/orders";
import { useNavigate } from "react-router-dom";

export default function Checkout() {
  const { cart, totals, clearCart } = useCart();
  const navigate = useNavigate();

  const [shipping, setShipping] = useState({
    name: "",
    phone: "",
    addressLine1: "",
    city: "",
    state: "",
    pincode: "",
  });

  const [paymentMethod, setPaymentMethod] = useState("COD");
  const [err, setErr] = useState("");
  const [placing, setPlacing] = useState(false);

  const onShipChange = (key) => (e) =>
    setShipping((prev) => ({ ...prev, [key]: e.target.value }));

  const validate = () => {
    if (!cart.length) return "Cart is empty";
    if (!shipping.name.trim()) return "Name is required";
    if (!shipping.phone.trim()) return "Phone is required";
    if (!/^\d{10}$/.test(shipping.phone.trim()))
      return "Phone must be 10 digits";
    if (!shipping.addressLine1.trim()) return "Address Line 1 is required";
    if (!shipping.city.trim()) return "City is required";
    if (!shipping.state.trim()) return "State is required";
    if (!shipping.pincode.trim()) return "Pincode is required";
    if (!/^\d{6}$/.test(shipping.pincode.trim()))
      return "Pincode must be 6 digits";
    return "";
  };

  const placeOrder = async () => {
    setErr("");
    const v = validate();
    if (v) return setErr(v);

    setPlacing(true);
    try {
      const payload = {
        items: cart.map((p) => ({
          productId: p._id,
          qty: p.qty,
        })),

        // ✅ matches your schema
        shippingAddress: {
          name: shipping.name.trim(),
          phone: shipping.phone.trim(),
          addressLine1: shipping.addressLine1.trim(),
          city: shipping.city.trim(),
          state: shipping.state.trim(),
          pincode: shipping.pincode.trim(),
        },

        // ✅ backend can map this to payment.method
        paymentMethod,
      };

      const res = await createOrder(payload);

      clearCart();
      const newOrderId = res.data?.order?._id;
      if (newOrderId) navigate(`/orders/${newOrderId}`);
      else navigate("/orders");
    } catch (e) {
      setErr(e?.response?.data?.message || "Failed to place order");
    } finally {
      setPlacing(false);
    }
  };

  return (
    <div className="max-w-xl mx-auto bg-white border rounded-xl p-6">
      <h2 className="text-xl font-bold">Checkout</h2>

      {err && <div className="mt-3 text-sm text-red-600">{err}</div>}

      <div className="mt-4 space-y-3">
        <div>
          <label className="text-sm font-medium text-gray-700">Full Name</label>
          <input
            className="w-full border rounded px-3 py-2 mt-1"
            placeholder="Your name"
            value={shipping.name}
            onChange={onShipChange("name")}
          />
        </div>

        <div>
          <label className="text-sm font-medium text-gray-700">Phone</label>
          <input
            className="w-full border rounded px-3 py-2 mt-1"
            placeholder="10-digit mobile"
            value={shipping.phone}
            onChange={onShipChange("phone")}
            inputMode="numeric"
          />
        </div>

        <div>
          <label className="text-sm font-medium text-gray-700">
            Address Line 1
          </label>
          <textarea
            className="w-full border rounded px-3 py-2 mt-1"
            rows={3}
            placeholder="House/Flat, Street, Area, Landmark"
            value={shipping.addressLine1}
            onChange={onShipChange("addressLine1")}
          />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          <div>
            <label className="text-sm font-medium text-gray-700">City</label>
            <input
              className="w-full border rounded px-3 py-2 mt-1"
              placeholder="City"
              value={shipping.city}
              onChange={onShipChange("city")}
            />
          </div>

          <div>
            <label className="text-sm font-medium text-gray-700">State</label>
            <input
              className="w-full border rounded px-3 py-2 mt-1"
              placeholder="State"
              value={shipping.state}
              onChange={onShipChange("state")}
            />
          </div>

          <div>
            <label className="text-sm font-medium text-gray-700">Pincode</label>
            <input
              className="w-full border rounded px-3 py-2 mt-1"
              placeholder="6-digit pincode"
              value={shipping.pincode}
              onChange={onShipChange("pincode")}
              inputMode="numeric"
            />
          </div>
        </div>

        <div>
          <label className="text-sm font-medium text-gray-700">
            Payment Method
          </label>
          <select
            className="w-full border rounded px-3 py-2 mt-1"
            value={paymentMethod}
            onChange={(e) => setPaymentMethod(e.target.value)}
          >
            <option value="COD">Cash on Delivery</option>
            <option value="UPI">UPI</option>
            <option value="CARD">Card</option>
          </select>
        </div>

        <div className="flex justify-between text-gray-700 pt-2">
          <span>Total</span>
          <span className="font-bold">₹{totals.subtotal}</span>
        </div>

        <button
          onClick={placeOrder}
          disabled={placing}
          className="w-full px-4 py-2 rounded bg-green-600 text-white disabled:opacity-60"
        >
          {placing ? "Placing..." : "Place Order"}
        </button>

        <p className="text-xs text-gray-500">
          Note: UPI/Card selection is saved in order. No Payment gateway.
        </p>
      </div>
    </div>
  );
}
