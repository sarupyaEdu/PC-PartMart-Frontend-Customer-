import { Link } from "react-router-dom";

export default function Home() {
  return (
    <div className="bg-white border rounded-xl p-6">
      <h1 className="text-3xl font-bold">Welcome to ComputerStore</h1>
      <p className="text-gray-600 mt-2">
        Build your PC with the best components — fast delivery, genuine parts.
      </p>

      <div className="mt-6 flex gap-3">
        <label className="text-gray-700">Most Discounted Products</label>
        
        <Link to="/products" className="px-5 py-2 rounded bg-black text-white">
          Shop Products
        </Link>
        <Link to="/cart" className="px-5 py-2 rounded border">
          View Cart
        </Link>
      </div>
    </div>
  );
}
