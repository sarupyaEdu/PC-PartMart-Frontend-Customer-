import { useEffect, useMemo, useState } from "react";
import { useParams } from "react-router-dom";
import {
  getOrder,
  requestRR,
  cancelOrder,
  cancelRR,
  cancelItems,
} from "../api/orders";

const fmt = (n) => `₹${Number(n || 0).toFixed(0)}`;

export default function OrderDetails() {
  const { id } = useParams();
  const [order, setOrder] = useState(null);
  const [reason, setReason] = useState("");
  const [msg, setMsg] = useState("");
  const [err, setErr] = useState("");
  const [type, setType] = useState("RETURN");
  const [cancelReason, setCancelReason] = useState("");
  const [cancelLoading, setCancelLoading] = useState(false);
  const [selected, setSelected] = useState({}); // { productId: true/false }
  const [qtyMap, setQtyMap] = useState({}); // { productId: number }
  const [partialCancelMode, setPartialCancelMode] = useState(false);

  const pidOf = (it) => String(it?.productId || it?._id || "");
  const load = async () => {
    setErr("");
    try {
      const res = await getOrder(id);
      setOrder(res.data?.order || res.data);
    } catch (e) {
      setErr(e?.response?.data?.message || "Failed to load order");
    }
  };

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id]);

  useEffect(() => {
    if (!order?.items?.length) return;

    const initSelected = {};
    const initQty = {};

    for (const it of order.items) {
      const pid = pidOf(it);
      initSelected[pid] = false;
      initQty[pid] = 1;
    }

    setSelected(initSelected);
    setQtyMap(initQty);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [order?._id]);

  const submitRR = async () => {
    setMsg("");
    setErr("");

    try {
      const items = (order.items || [])
        .map((it) => {
          const pid = pidOf(it);
          if (!selected[pid]) return null;

          const eligibleRRQty = Math.max(
            0,
            Number(it?.qty || 0) -
              Number(it?.cancelledQty || 0) -
              Number(it?.returnedQty || 0) -
              Number(it?.replacedQty || 0)
          );

          const q = Math.min(Number(qtyMap[pid] || 1), eligibleRRQty);
          if (q <= 0) return null;

          return { productId: pid, qty: q };
        })
        .filter(Boolean);

      if (!items.length) {
        setErr("Select at least 1 item and quantity for Return/Replacement.");
        return;
      }

      await requestRR(id, { type, reason, items });
      setMsg("Return/Replacement request submitted.");
      setReason("");
      await load();
    } catch (e) {
      setErr(e?.response?.data?.message || "RR request failed");
    }
  };

  // ✅ Hooks must be called BEFORE any conditional return
  const subtotal = useMemo(() => {
    if (!order) return 0;

    return (order.items || []).reduce((sum, it) => {
      const qty = Number(it?.qty ?? 1);
      const unit = Number(it?.priceSnapshot ?? 0);
      return sum + unit * qty;
    }, 0);
  }, [order]);

  const totalAmount = useMemo(() => {
    if (!order) return 0;
    return Number(order.totalAmount ?? subtotal);
  }, [order, subtotal]);

  const addr = useMemo(() => {
    return order?.shippingAddress || {};
  }, [order]);

  const status = String(order?.status || "").toUpperCase();
  const isCancelled = status === "CANCELLED";
  const canRR = status === "DELIVERED";
  const canCancel = ["PLACED", "CONFIRMED"].includes(status);

  const rrStatus = String(order?.returnRequest?.status || "NONE").toUpperCase();
  const rrType = String(order?.returnRequest?.type || "NONE").toUpperCase();
  const canCancelRR = canRR && rrStatus === "REQUESTED";
  const selectedForCancelCount = useMemo(() => {
    if (!canCancel) return 0;

    return (order?.items || []).reduce((count, it) => {
      const pid = pidOf(it);
      const eligibleCancelQty = Math.max(
        0,
        Number(it?.qty || 0) - Number(it?.cancelledQty || 0)
      );
      const picked = !!selected[pid];
      const pickedQty = Number(qtyMap[pid] || 1);

      // count only if selected AND qty valid AND eligible > 0
      if (picked && eligibleCancelQty > 0 && pickedQty > 0) return count + 1;
      return count;
    }, 0);
  }, [canCancel, order, selected, qtyMap]);
  // ✅ Now it's safe to return conditionally
  if (!order) return <div>Loading...</div>;
  const displayStatus = (() => {
    // 🔵 Refund overrides everything
    if (order.payment?.status === "REFUNDED") {
      return "ADMIN INITIATED REFUND";
    }

    if (rrStatus === "REQUESTED") {
      return rrType === "RETURN" ? "RETURN REQUESTED" : "REPLACEMENT REQUESTED";
    }

    if (rrStatus === "APPROVED") {
      return rrType === "RETURN"
        ? "ADMIN APPROVED RETURN"
        : "ADMIN APPROVED REPLACEMENT";
    }

    if (rrStatus === "REJECTED") {
      return rrType === "RETURN"
        ? "RETURN REQUEST REJECTED"
        : "REPLACEMENT REQUEST REJECTED";
    }

    // COMPLETED or NONE → fall back
    return order.status;
  })();

  const doCancel = async () => {
    setMsg("");
    setErr("");

    if (!canCancel) return;

    const ok = window.confirm("Are you sure you want to cancel this order?");
    if (!ok) return;

    try {
      setCancelLoading(true);
      await cancelOrder(id, { reason: cancelReason }); // reason optional
      setMsg("Order cancelled successfully.");
      setCancelReason("");
      await load();
    } catch (e) {
      setErr(e?.response?.data?.message || "Cancel failed");
    } finally {
      setCancelLoading(false);
    }
  };

  const doPartialCancel = async () => {
    setMsg("");
    setErr("");

    if (!canCancel) return;

    try {
      const items = (order.items || [])
        .map((it) => {
          const pid = pidOf(it);
          if (!selected[pid]) return null;

          const eligibleCancelQty = Math.max(
            0,
            Number(it?.qty || 0) - Number(it?.cancelledQty || 0)
          );

          const q = Math.min(Number(qtyMap[pid] || 1), eligibleCancelQty);
          if (q <= 0) return null;

          return { productId: pid, qty: q };
        })
        .filter(Boolean);

      if (!items.length) {
        setErr("Select at least 1 item and quantity to cancel.");
        return;
      }

      await cancelItems(id, { items, reason: cancelReason });
      setMsg("Selected items cancelled.");
      setCancelReason("");
      setPartialCancelMode(false);
      await load();
    } catch (e) {
      setErr(e?.response?.data?.message || "Partial cancel failed");
    }
  };

  const togglePartialCancelMode = () => {
    setMsg("");
    setErr("");

    setPartialCancelMode((prev) => {
      const next = !prev;

      // When closing OR opening, reset selections (clean UX)
      const initSelected = {};
      const initQty = {};
      for (const it of order.items || []) {
        const pid = pidOf(it);
        initSelected[pid] = false;
        initQty[pid] = 1;
      }
      setSelected(initSelected);
      setQtyMap(initQty);

      return next;
    });
  };

  const cancelRRRequest = async () => {
    setMsg("");
    setErr("");

    const ok = window.confirm("Cancel your return/replacement request?");
    if (!ok) return;

    try {
      await cancelRR(id);
      setMsg("Return/Replacement request cancelled.");
      await load();
    } catch (e) {
      setErr(e?.response?.data?.message || "Failed to cancel RR request");
    }
  };

  return (
    <div className="bg-white border rounded-xl p-6">
      <h2 className="text-xl font-bold">Order Details</h2>

      <div className="mt-2 flex items-center justify-between text-gray-700">
        {/* Status (left) */}
        <div>
          Status:{" "}
          <span
            className={`font-semibold ${
              rrStatus === "REQUESTED"
                ? "text-orange-600"
                : rrStatus === "APPROVED"
                ? "text-blue-700"
                : rrStatus === "REJECTED"
                ? "text-red-600"
                : ""
            }`}
          >
            {displayStatus}
          </span>
        </div>

        {/* Order ID (right) */}
        <div className="text-sm text-gray-600">
          Order ID:{" "}
          <span className="font-mono font-medium text-gray-800">
            {String(order._id).slice(-6).toUpperCase()}
          </span>
        </div>
      </div>

      {/* ✅ Global messages for Cancel + RR */}
      {msg && <div className="mt-2 text-sm text-green-700">{msg}</div>}
      {err && <div className="mt-2 text-sm text-red-600">{err}</div>}

      {/* Payment Details */}
      <div className="mt-4 border rounded-lg p-4 bg-gray-50">
        <h3 className="font-bold mb-2">Payment Details</h3>

        <div className="text-sm text-gray-700 space-y-1">
          <div>
            <span className="text-gray-600">Method:</span>{" "}
            <span className="font-medium">
              {order.payment?.method || "N/A"}
            </span>
          </div>

          <div>
            <span className="text-gray-600">Status:</span>{" "}
            <span
              className={`font-medium ${
                order.payment?.status === "PAID"
                  ? "text-green-700"
                  : order.payment?.status === "REFUNDED"
                  ? "text-blue-700"
                  : order.payment?.status === "FAILED"
                  ? "text-red-600"
                  : "text-gray-800"
              }`}
            >
              {order.payment?.status || "N/A"}
            </span>
          </div>

          {order.payment?.txnId && (
            <div>
              <span className="text-gray-600">Transaction ID:</span>{" "}
              <span className="font-mono text-gray-800">
                {order.payment.txnId}
              </span>
            </div>
          )}

          {/* COD not collected note */}
          {order.payment?.method === "COD" &&
            order.payment?.status === "FAILED" && (
              <div className="mt-2 text-xs text-gray-600 italic">
                Note: Since this order was Cash on Delivery and cancelled before
                delivery, payment was not collected.
              </div>
            )}

          {/* Refund processing note */}
          {order.payment?.status === "REFUNDED" && (
            <div className="mt-2 text-xs text-blue-700 italic">
              Note: The refund has been initiated and will reflect in your
              original payment method within 3–5 business days.
            </div>
          )}
        </div>
      </div>

      {/* Address */}
      <div className="mt-6 border-t pt-4">
        <h3 className="font-bold mb-2">Delivery Address</h3>

        {addr?.name || addr?.addressLine1 || addr?.city || addr?.phone ? (
          <div className="text-sm text-gray-700 leading-6">
            {addr?.name && <div className="font-semibold">{addr.name}</div>}

            {addr?.addressLine1 && <div>{addr.addressLine1}</div>}

            {(addr?.city || addr?.state || addr?.pincode) && (
              <div>
                {[addr?.city, addr?.state].filter(Boolean).join(", ")}
                {addr?.pincode ? ` - ${addr.pincode}` : ""}
              </div>
            )}

            {addr?.phone && (
              <div>
                <span className="text-gray-600">Phone:</span>{" "}
                <span className="font-medium text-gray-800">{addr.phone}</span>
              </div>
            )}
          </div>
        ) : (
          <p className="text-sm text-gray-600">Address not found.</p>
        )}
      </div>

      {/* Items */}
      <div className="mt-6 border-t pt-4">
        <h3 className="font-bold mb-2">Items</h3>

        <div className="space-y-2">
          {(order.items || []).map((it, idx) => {
            const title = it?.titleSnapshot || "Item";
            const qty = Number(it?.qty ?? 1);
            const unit = Number(it?.priceSnapshot ?? 0);

            const cancelledQty = Number(it?.cancelledQty || 0);
            const activeQty = Math.max(0, qty - cancelledQty);

            const isFullyCancelledItem = activeQty === 0;
            const isPartiallyCancelledItem = cancelledQty > 0 && activeQty > 0;

            // ✅ Standard: show line total for ACTIVE qty only
            const lineTotal = unit * activeQty;

            const pid = pidOf(it);

            const eligibleCancelQty = Math.max(
              0,
              Number(it?.qty || 0) - Number(it?.cancelledQty || 0)
            );

            const eligibleRRQty = Math.max(
              0,
              Number(it?.qty || 0) -
                Number(it?.cancelledQty || 0) -
                Number(it?.returnedQty || 0) -
                Number(it?.replacedQty || 0)
            );

            const eligible = canCancel
              ? eligibleCancelQty
              : canRR
              ? eligibleRRQty
              : 0;

            return (
              <div
                key={idx}
                className="border rounded p-3 flex justify-between items-start"
              >
                <div>
                  <div className="flex items-center gap-2">
                    <div
                      className={`font-semibold ${
                        isFullyCancelledItem ? "line-through text-gray-400" : ""
                      }`}
                    >
                      {title}
                    </div>

                    {isFullyCancelledItem && (
                      <span className="text-xs px-2 py-0.5 rounded bg-gray-200 text-gray-700">
                        Cancelled
                      </span>
                    )}

                    {isPartiallyCancelledItem && (
                      <span className="text-xs px-2 py-0.5 rounded bg-yellow-100 text-yellow-800">
                        Partially cancelled
                      </span>
                    )}
                  </div>

                  <div className="text-base font-bold text-gray-600">
                    Qty: {qty}
                    {cancelledQty > 0 && (
                      <span className="ml-2 text-xs text-gray-500">
                        (Cancelled: {cancelledQty}, Active: {activeQty})
                      </span>
                    )}
                  </div>

                  <div className="text-sm text-gray-600">
                    Unit:{" "}
                    <span className="font-medium text-gray-800">
                      {fmt(unit)}
                    </span>
                  </div>
                </div>

                <div className="text-right flex flex-col items-end gap-2">
                  {
                    // ✅ For Partial Cancel: show only when user clicked "Cancel partial items"
                    ((canCancel && !isCancelled && partialCancelMode) ||
                      // ✅ For RR: keep as it is (always visible when RR can be requested)
                      (canRR && !isCancelled && rrStatus === "NONE")) && (
                      <div className="mt-2 flex items-center gap-3">
                        <input
                          type="checkbox"
                          checked={!!selected[pid]}
                          disabled={eligible <= 0}
                          onChange={(e) =>
                            setSelected((s) => ({
                              ...s,
                              [pid]: e.target.checked,
                            }))
                          }
                        />

                        <input
                          type="number"
                          min={1}
                          max={eligible}
                          value={qtyMap[pid] || 1}
                          disabled={!selected[pid] || eligible <= 0}
                          onChange={(e) =>
                            setQtyMap((m) => ({
                              ...m,
                              [pid]: Number(e.target.value || 1),
                            }))
                          }
                          className="w-16 border rounded px-2 py-1 text-right"
                        />
                      </div>
                    )
                  }

                  {((canCancel && partialCancelMode) ||
                    (canRR && rrStatus === "NONE")) && (
                    <span className="text-xs text-gray-500">
                      Eligible: {eligible}
                    </span>
                  )}

                  <div className="text-sm text-gray-600">Line total</div>
                  <div className="font-bold">
                    {activeQty === 0 ? "₹0" : fmt(unit * activeQty)}
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Totals */}
        <div className="mt-4 border rounded p-4">
          <div className="flex justify-between text-sm text-gray-700">
            <span>Original Total</span>
            <span className="font-medium">{fmt(subtotal)}</span>
          </div>

          <div className="flex justify-between mt-3 pt-3 border-t">
            <span className="font-bold">Payable Total</span>
            <span className="font-bold">{fmt(totalAmount)}</span>
          </div>
        </div>
      </div>

      {canCancel && !isCancelled && (
        <div className="mt-6 border-t pt-4">
          <h3 className="font-bold">Cancel Order</h3>

          <div className="mt-3 flex flex-col md:flex-row gap-2">
            <input
              value={cancelReason}
              onChange={(e) => setCancelReason(e.target.value)}
              placeholder="Cancel reason (optional)"
              className="flex-1 border rounded px-3 py-2"
              disabled={cancelLoading}
            />

            {/* ✅ Step 1 button */}
            {!partialCancelMode && (
              <button
                disabled={cancelLoading}
                onClick={togglePartialCancelMode}
                className="px-4 py-2 rounded bg-blue-600 text-white disabled:opacity-60"
              >
                Cancel partial items
              </button>
            )}

            {/* ✅ Step 2 button (same place) */}
            {partialCancelMode && (
              <>
                <button
                  disabled={cancelLoading}
                  onClick={togglePartialCancelMode}
                  className="px-4 py-2 rounded border border-gray-300 text-gray-800 hover:bg-gray-50 disabled:opacity-60"
                >
                  Close
                </button>

                <button
                  disabled={cancelLoading || selectedForCancelCount === 0}
                  onClick={doPartialCancel}
                  className="px-4 py-2 rounded bg-blue-600 text-white disabled:opacity-60"
                >
                  Cancel selected items
                </button>
              </>
            )}

            {/* Full cancel stays always */}
            <button
              disabled={cancelLoading}
              onClick={doCancel}
              className="px-4 py-2 rounded bg-red-600 text-white disabled:opacity-60"
            >
              {cancelLoading ? "Cancelling..." : "Cancel Order"}
            </button>
          </div>
        </div>
      )}

      {canRR && !isCancelled && (
        <div className="mt-6 border-t pt-4">
          <h3 className="font-bold">Return / Replacement</h3>

          {/* Show current RR status (if any) */}
          {rrStatus !== "NONE" && (
            <p className="text-sm text-gray-700 mt-2">
              RR Status: <span className="font-semibold">{rrStatus}</span>{" "}
              {rrType !== "NONE" ? (
                <span className="text-gray-500">({rrType})</span>
              ) : null}
            </p>
          )}

          {/* If NO request exists, show Request form */}
          {rrStatus === "NONE" && (
            <div className="mt-3 flex flex-col md:flex-row gap-2">
              <select
                value={type}
                onChange={(e) => setType(e.target.value)}
                className="border rounded px-3 py-2 md:w-52"
              >
                <option value="RETURN">RETURN</option>
                <option value="REPLACEMENT">REPLACEMENT</option>
              </select>

              <input
                value={reason}
                onChange={(e) => setReason(e.target.value)}
                placeholder="Reason (e.g., damaged, wrong item)"
                className="flex-1 border rounded px-3 py-2"
              />

              <button
                disabled={!reason.trim()}
                onClick={submitRR}
                className="px-4 py-2 rounded bg-red-600 text-white disabled:opacity-60"
              >
                Request
              </button>
            </div>
          )}

          {/* If REQUESTED, show Cancel RR button (ONLY) */}
          {canCancelRR && (
            <div className="mt-3">
              <button
                onClick={cancelRRRequest}
                className="px-4 py-2 rounded border border-gray-300 text-gray-800 hover:bg-gray-50"
              >
                Cancel RR Request
              </button>
            </div>
          )}

          {/* If admin already decided, show info (no cancel button) */}
          {rrStatus !== "NONE" && rrStatus !== "REQUESTED" && (
            <p className="text-sm text-gray-600 mt-3">
              This request can no longer be cancelled.
            </p>
          )}
        </div>
      )}
    </div>
  );
}
