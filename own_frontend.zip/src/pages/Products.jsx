import { useEffect, useState } from "react";
import { listProducts } from "../api/products";
import ProductCard from "../components/ProductCard";

export default function Products() {
  console.log("✅ PRODUCTS PAGE LOADED - CUSTOMER FRONTEND");

  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);

  // search & sort
  const [search, setSearch] = useState("");
  const [sort, setSort] = useState("");

  const fetchProducts = async () => {
    setLoading(true);
    try {
      const res = await listProducts({
        search: search || undefined,
        sort: sort || undefined,
        page: 1,
        limit: 20,
      });

      setItems(res.data?.products || []);
    } catch (err) {
      console.error("PRODUCT FETCH ERROR:", err?.response?.data || err.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchProducts();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <div>
      {/* 🔍 Search + Sort Bar */}
      <div className="bg-white border rounded-xl p-4 mb-6 flex flex-col md:flex-row gap-3 md:items-center md:justify-between">
        <div className="flex gap-2 w-full md:w-2/3">
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search products..."
            className="w-full border rounded px-3 py-2"
          />
          <button
            onClick={fetchProducts}
            className="px-4 py-2 rounded bg-black text-white"
          >
            Search
          </button>
        </div>

        <div className="flex gap-2">
          <select
            value={sort}
            onChange={(e) => setSort(e.target.value)}
            className="border rounded px-3 py-2"
          >
            <option value="">Sort</option>
            <option value="priceAsc">Price: Low to High</option>
            <option value="priceDesc">Price: High to Low</option>
            <option value="newest">Newest</option>
          </select>

          <button onClick={fetchProducts} className="px-4 py-2 rounded border">
            Apply
          </button>
        </div>
      </div>

      {/* 🛍 Products Grid */}
      {loading ? (
        <div className="text-gray-600">Loading products...</div>
      ) : items.length === 0 ? (
        <div className="text-gray-600">No products found.</div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
          {items.map((product) => (
            <ProductCard key={product._id} product={product} />
          ))}
        </div>
      )}
    </div>
  );
}
