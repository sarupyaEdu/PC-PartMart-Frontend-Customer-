import { useEffect, useState } from "react";
import { myOrders } from "../api/orders";
import { Link } from "react-router-dom";

export default function MyOrders() {
  const [items, setItems] = useState([]);
  const [err, setErr] = useState("");
  

  useEffect(() => {
    (async () => {
      try {
        const res = await myOrders();
        setItems(res.data?.orders || res.data || []);
      } catch (e) {
        setErr(e?.response?.data?.message || "Failed to load orders");
      }
    })();
  }, []);

  return (
    <div className="bg-white border rounded-xl p-6">
      <h2 className="text-xl font-bold">My Orders</h2>
      {err && <div className="mt-3 text-sm text-red-600">{err}</div>}

      <div className="mt-4 space-y-3">
        {items.map((o) => (
          <div
            key={o._id}
            className="border rounded-lg p-4 flex justify-between items-center"
          >
            <div>
              <div className="font-semibold">
                Order #{o._id.slice(-6).toUpperCase()}
              </div>

              <div className="text-sm text-gray-600">Status: {o.status}</div>
            </div>
            <Link to={`/orders/${o._id}`} className="px-3 py-2 rounded border">
              View
            </Link>
          </div>
        ))}
        {!items.length && !err && (
          <div className="text-gray-600">No orders yet.</div>
        )}
      </div>
    </div>
  );
}
