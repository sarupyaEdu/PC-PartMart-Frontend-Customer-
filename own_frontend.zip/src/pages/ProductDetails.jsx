import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import { getProductBySlug } from "../api/products";
import { useCart } from "../context/CartContext";

export default function ProductDetails() {
  const { slug } = useParams();
  const { addToCart } = useCart();
  const [p, setP] = useState(null);

  useEffect(() => {
    (async () => {
      try {
        const res = await getProductBySlug(slug);
        const data = res.data?.product || res.data; // ✅ define data

        console.log("PRODUCT DETAILS FULL DATA:", data);
        console.log("PRODUCT DETAILS IMAGES:", data?.images);

        setP(data);
      } catch (e) {
        console.log("DETAILS FETCH ERROR:", e?.response?.data || e.message);
      }
    })();
  }, [slug]);

  if (!p) return <div>Loading...</div>;

  return (
    <div className="bg-white border rounded-xl p-6 grid md:grid-cols-2 gap-6">
      <img
        src={p?.images?.[0]?.url}
        alt={p?.name}
        className="w-full object-contain"
      />

      <div>
        <h1 className="text-2xl font-bold">{p.title}</h1>
        <p className="text-green-700 font-bold text-xl mt-2">₹{p.price}</p>

        <p className="text-gray-700 mt-4">{p.description}</p>

        <div className="mt-6 flex gap-3">
          <button
            onClick={() => addToCart(p, 1)}
            className="px-5 py-2 rounded bg-black text-white"
          >
            Add to Cart
          </button>
        </div>
      </div>
    </div>
  );
}
