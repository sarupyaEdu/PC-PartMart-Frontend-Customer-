import { Link, useNavigate } from "react-router-dom";
import { useCart } from "../context/CartContext";

export default function Cart() {
  const { cart, updateQty, removeFromCart, totals } = useCart();
  const navigate = useNavigate();

  if (!cart.length) {
    return (
      <div className="bg-white border rounded-xl p-6">
        <h2 className="text-xl font-bold">Your cart is empty</h2>
        <Link
          to="/products"
          className="inline-block mt-4 px-4 py-2 rounded bg-black text-white"
        >
          Shop Products
        </Link>
      </div>
    );
  }

  return (
    <div className="grid lg:grid-cols-3 gap-6">
      {/* 🛒 Cart Items */}
      <div className="lg:col-span-2 bg-white border rounded-xl p-4">
        <h2 className="text-xl font-bold mb-4">Cart</h2>

        <div className="space-y-4">
          {cart.map((p) => (
            <div key={p._id} className="flex gap-4 border rounded-lg p-3">
              {/* ✅ Correct image access */}
              {p?.images?.[0]?.url ? (
                <img
                  src={p.images[0].url}
                  alt={p.title}
                  className="h-20 w-20 object-contain"
                />
              ) : (
                <div className="h-20 w-20 bg-gray-100 flex items-center justify-center text-xs text-gray-500">
                  No Image
                </div>
              )}

              <div className="flex-1">
                {/* ✅ Correct title */}
                <div className="font-semibold">{p.title}</div>
                <div className="text-green-700 font-bold">₹{p.price}</div>

                <div className="mt-2 flex items-center gap-3">
                  <input
                    type="number"
                    min="1"
                    value={p.qty}
                    onChange={(e) =>
                      updateQty(p._id, Math.max(1, Number(e.target.value)))
                    }
                    className="w-20 border rounded px-2 py-1"
                  />
                  <button
                    onClick={() => removeFromCart(p._id)}
                    className="px-3 py-1 rounded border"
                  >
                    Remove
                  </button>
                </div>
              </div>

              <div className="font-bold">₹{Number(p.price) * p.qty}</div>
            </div>
          ))}
        </div>
      </div>

      {/* 🧾 Summary */}
      <div className="bg-white border rounded-xl p-4 h-fit">
        <h3 className="text-lg font-bold">Summary</h3>

        <div className="mt-3 flex justify-between">
          <span>Subtotal</span>
          <span className="font-bold">₹{totals.subtotal}</span>
        </div>

        <button
          onClick={() => navigate("/checkout")}
          className="mt-5 w-full px-4 py-2 rounded bg-green-600 text-white"
        >
          Proceed to Checkout
        </button>
      </div>
    </div>
  );
}
