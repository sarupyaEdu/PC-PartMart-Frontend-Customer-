import { useState } from "react";
import { loginUser } from "../api/auth";
import { useAuth } from "../context/AuthContext";
import { useNavigate, Link } from "react-router-dom";

export default function Login() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [err, setErr] = useState("");
  const { refresh } = useAuth();
  const navigate = useNavigate();

  const submit = async (e) => {
    e.preventDefault();
    setErr("");
    try {
      const res = await loginUser({ email, password });
      const token = res.data?.token;
      if (!token) throw new Error("Token not received");
      localStorage.setItem("customerToken", token);
      await refresh();
      navigate("/");
    } catch (e2) {
      setErr(e2?.response?.data?.message || e2.message || "Login failed");
    }
  };

  return (
    <div className="max-w-md mx-auto bg-white border rounded-xl p-6">
      <h2 className="text-xl font-bold">Login</h2>

      {err && <div className="mt-3 text-sm text-red-600">{err}</div>}

      <form onSubmit={submit} className="mt-4 space-y-3">
        <input
          className="w-full border rounded px-3 py-2"
          placeholder="Email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
        />
        <input
          className="w-full border rounded px-3 py-2"
          placeholder="Password"
          type="password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
        />

        <button className="w-full px-4 py-2 rounded bg-black text-white">
          Login
        </button>
      </form>

      <p className="text-sm text-gray-600 mt-3">
        New here?{" "}
        <Link className="underline" to="/register">
          Create account
        </Link>
      </p>
    </div>
  );
}
