import { Link, useNavigate } from "react-router-dom";
import { useCart } from "../context/CartContext";
import { useAuth } from "../context/AuthContext";

export default function Navbar() {
  const { cart } = useCart();
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  const cartCount = cart.reduce((sum, x) => sum + x.qty, 0);

  const handleLogout = () => {
    logout();
    navigate("/");
  };

  return (
    <div className="sticky top-0 z-50 bg-white border-b">
      <div className="max-w-6xl mx-auto px-4 py-3 flex items-center justify-between">
        <Link to="/" className="font-bold text-xl">
          ComputerStore
        </Link>

        <div className="flex items-center gap-4">
          <Link to="/products" className="hover:underline">
            Products
          </Link>

          <Link to="/cart" className="hover:underline">
            Cart <span className="text-sm text-gray-600">({cartCount})</span>
          </Link>

          {user ? (
            <>
              <Link to="/orders" className="hover:underline">
                My Orders
              </Link>
              <button
                onClick={handleLogout}
                className="px-3 py-1 rounded bg-black text-white"
              >
                Logout
              </button>
            </>
          ) : (
            <>
              <Link to="/login" className="px-3 py-1 rounded border">
                Login
              </Link>
              <Link
                to="/register"
                className="px-3 py-1 rounded bg-black text-white"
              >
                Register
              </Link>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
