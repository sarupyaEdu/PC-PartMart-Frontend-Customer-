import { Link } from "react-router-dom";
import { useCart } from "../context/CartContext";

export default function ProductCard({ product }) {
  const { addToCart } = useCart();

  const imgUrl = product?.images?.[0]?.url; // ✅ correct for your backend

  return (
    <div className="border rounded-lg p-4 shadow hover:shadow-lg bg-white">
      {imgUrl ? (
        <img
          src={imgUrl}
          alt={product?.title}
          className="h-40 w-full object-contain"
        />
      ) : (
        <div className="h-40 w-full bg-gray-100 rounded flex items-center justify-center text-gray-500">
          No Image
        </div>
      )}

      <h3 className="font-semibold mt-2 line-clamp-2">{product?.title}</h3>
      {product?.discountPrice ? (
        <>
          <p className="text-gray-400 text-sm line-through">
            ₹{product?.price}
          </p>
          <p className="text-green-700 font-bold text-lg">
            ₹{product?.discountPrice}
          </p>
        </>
      ) : (
        <p className="text-gray-700 font-bold text-lg">₹{product?.price}</p>
      )}

      <div className="mt-3 flex gap-2">
        <button
          onClick={() => addToCart(product, 1)}
          className="px-3 py-2 rounded bg-black text-white w-full"
        >
          Add
        </button>

        <Link
          to={`/product/${product?.slug}`}
          className="px-3 py-2 rounded border w-full text-center"
        >
          View
        </Link>
      </div>
    </div>
  );
}
